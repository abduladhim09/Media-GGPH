
import React from 'react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Cell,
  PieChart,
  Pie
} from 'recharts';
import { MOCK_CHART_DATA, PLATFORM_COLORS } from '../constants';

const AnalyticsView: React.FC = () => {
  const platformMarketShare = [
    { name: 'Instagram', value: 45, color: PLATFORM_COLORS.instagram },
    { name: 'TikTok', value: 30, color: PLATFORM_COLORS.tiktok },
    { name: 'Facebook', value: 15, color: PLATFORM_COLORS.facebook },
    { name: 'Twitter', value: 10, color: PLATFORM_COLORS.twitter },
  ];

  return (
    <div className="space-y-8 animate-in slide-in-from-bottom-4 duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Engagement Distribution */}
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
          <h2 className="text-lg font-bold text-slate-800 mb-6">Daily Engagement Distribution</h2>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MOCK_CHART_DATA}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{ fill: '#f8fafc' }}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                />
                <Bar dataKey="engagement" radius={[6, 6, 0, 0]}>
                  {MOCK_CHART_DATA.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={index % 2 === 0 ? '#6366f1' : '#c7d2fe'} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Platform Share */}
        <div className="bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
          <h2 className="text-lg font-bold text-slate-800 mb-6">Traffic Origin</h2>
          <div className="h-64 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={platformMarketShare}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={8}
                  dataKey="value"
                >
                  {platformMarketShare.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="mt-6 space-y-3">
            {platformMarketShare.map((p) => (
              <div key={p.name} className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: p.color }}></div>
                  <span className="text-slate-600">{p.name}</span>
                </div>
                <span className="font-bold">{p.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tables or more stats could go here */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100">
          <h2 className="text-lg font-bold text-slate-800">Content Performance Leaderboard</h2>
        </div>
        <table className="w-full text-left">
          <thead className="bg-slate-50 text-slate-500 text-xs uppercase tracking-wider">
            <tr>
              <th className="px-6 py-4 font-semibold">Post Title</th>
              <th className="px-6 py-4 font-semibold">Platform</th>
              <th className="px-6 py-4 font-semibold">Engagement</th>
              <th className="px-6 py-4 font-semibold">Shares</th>
              <th className="px-6 py-4 font-semibold">ROI Score</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {[
              { title: 'Summer Collection Launch', platform: 'Instagram', eng: '12.4%', shares: 450, roi: 8.5 },
              { title: 'Behind the Scenes Reel', platform: 'TikTok', eng: '18.2%', shares: 1200, roi: 9.2 },
              { title: 'Why Sustainability Matters', platform: 'Linkedin', eng: '5.4%', shares: 120, roi: 7.1 },
            ].map((row, i) => (
              <tr key={i} className="hover:bg-slate-50 transition-colors">
                <td className="px-6 py-4 font-medium text-slate-800">{row.title}</td>
                <td className="px-6 py-4 text-slate-500">{row.platform}</td>
                <td className="px-6 py-4 font-semibold text-indigo-600">{row.eng}</td>
                <td className="px-6 py-4 text-slate-500">{row.shares}</td>
                <td className="px-6 py-4">
                  <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden max-w-[100px]">
                    <div 
                      className="bg-indigo-500 h-full rounded-full" 
                      style={{ width: `${row.roi * 10}%` }}
                    ></div>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default AnalyticsView;
