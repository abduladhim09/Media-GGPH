
import React from 'react';
import { Target, DollarSign, MousePointer2, Percent, TrendingUp, AlertCircle } from 'lucide-react';
import { PLATFORM_ICONS, PLATFORM_COLORS } from '../constants';
import { AdCampaign } from '../types';

const AdsManagerView: React.FC = () => {
  const campaigns: AdCampaign[] = [
    { id: '1', name: 'New Year Promo 2024', platform: 'facebook', status: 'active', budget: 5000, spent: 2450, cpc: 0.45, ctr: 2.5, roi: 4.2 },
    { id: '2', name: 'Winter Jackets - Lookalike', platform: 'instagram', status: 'active', budget: 3000, spent: 1200, cpc: 0.88, ctr: 1.8, roi: 3.5 },
    { id: '3', name: 'Gen Z Influence Drive', platform: 'tiktok', status: 'paused', budget: 10000, spent: 8500, cpc: 0.12, ctr: 5.4, roi: 6.8 },
  ];

  const summary = {
    totalSpend: campaigns.reduce((acc, c) => acc + c.spent, 0),
    avgCtr: (campaigns.reduce((acc, c) => acc + c.ctr, 0) / campaigns.length).toFixed(1),
    avgRoi: (campaigns.reduce((acc, c) => acc + c.roi, 0) / campaigns.length).toFixed(1)
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Top Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-indigo-50 text-indigo-600 rounded-xl">
              <DollarSign size={20} />
            </div>
            <p className="text-slate-500 font-medium">Monthly Ad Spend</p>
          </div>
          <p className="text-3xl font-bold">${summary.totalSpend.toLocaleString()}</p>
          <p className="text-xs text-emerald-500 font-bold mt-2 flex items-center">
            <TrendingUp size={14} className="mr-1" /> 12.5% vs last month
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-emerald-50 text-emerald-600 rounded-xl">
              <MousePointer2 size={20} />
            </div>
            <p className="text-slate-500 font-medium">Avg. Click-Through Rate</p>
          </div>
          <p className="text-3xl font-bold">{summary.avgCtr}%</p>
          <p className="text-xs text-emerald-500 font-bold mt-2 flex items-center">
            <TrendingUp size={14} className="mr-1" /> 0.4% vs last month
          </p>
        </div>
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-amber-50 text-amber-600 rounded-xl">
              <Percent size={20} />
            </div>
            <p className="text-slate-500 font-medium">Total ROI</p>
          </div>
          <p className="text-3xl font-bold">{summary.avgRoi}x</p>
          <p className="text-xs text-rose-500 font-bold mt-2 flex items-center">
            <AlertCircle size={14} className="mr-1" /> 2.1% under target
          </p>
        </div>
      </div>

      {/* Campaigns Table */}
      <div className="bg-white rounded-2xl border border-slate-100 shadow-sm overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h2 className="text-lg font-bold text-slate-800">Active Campaigns</h2>
          <button className="text-sm font-semibold text-indigo-600 hover:underline">View All Campaigns</button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-slate-50 text-slate-500 text-[10px] uppercase tracking-wider">
              <tr>
                <th className="px-6 py-4 font-bold">Campaign Name</th>
                <th className="px-6 py-4 font-bold">Status</th>
                <th className="px-6 py-4 font-bold">Budget</th>
                <th className="px-6 py-4 font-bold">Spent</th>
                <th className="px-6 py-4 font-bold">CPC</th>
                <th className="px-6 py-4 font-bold">CTR</th>
                <th className="px-6 py-4 font-bold">ROI</th>
                <th className="px-6 py-4 font-bold text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {campaigns.map((c) => (
                <tr key={c.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-6 py-5">
                    <div className="flex items-center gap-3">
                      <div className="p-1.5 rounded-lg text-white" style={{ backgroundColor: PLATFORM_COLORS[c.platform] }}>
                        {PLATFORM_ICONS[c.platform]}
                      </div>
                      <div>
                        <p className="font-semibold text-slate-800">{c.name}</p>
                        <p className="text-xs text-slate-400 capitalize">{c.platform}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5">
                    <span className={`px-2 py-1 rounded-full text-[10px] font-bold uppercase ${
                      c.status === 'active' ? 'bg-emerald-50 text-emerald-600' : 'bg-slate-100 text-slate-400'
                    }`}>
                      {c.status}
                    </span>
                  </td>
                  <td className="px-6 py-5 font-medium text-slate-600">${c.budget.toLocaleString()}</td>
                  <td className="px-6 py-5">
                    <div className="space-y-1">
                      <p className="text-sm font-semibold text-slate-800">${c.spent.toLocaleString()}</p>
                      <div className="w-24 h-1.5 bg-slate-100 rounded-full">
                        <div 
                          className="h-full bg-indigo-500 rounded-full" 
                          style={{ width: `${(c.spent/c.budget) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-5 text-slate-600">${c.cpc}</td>
                  <td className="px-6 py-5 text-slate-600">{c.ctr}%</td>
                  <td className="px-6 py-5 font-bold text-indigo-600">{c.roi}x</td>
                  <td className="px-6 py-5 text-right">
                    <button className="px-3 py-1 text-slate-400 hover:text-indigo-600 transition-colors font-bold text-lg">···</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default AdsManagerView;
