
import React, { useState } from 'react';
import { ChevronLeft, ChevronRight, Plus, Calendar as CalendarIcon, Filter, MoreHorizontal } from 'lucide-react';
import { PLATFORM_ICONS, PLATFORM_COLORS } from '../constants';
import { CalendarEvent, Platform } from '../types';

const CalendarView: React.FC = () => {
  const [currentDate, setCurrentDate] = useState(new Date());
  
  const events: CalendarEvent[] = [
    { id: '1', title: 'Product Launch Video', date: '2024-05-15', platform: 'instagram', status: 'scheduled', type: 'video' },
    { id: '2', title: 'Weekly Recap Story', date: '2024-05-16', platform: 'facebook', status: 'draft', type: 'story' },
    { id: '3', title: 'Marketing Tips Carousel', date: '2024-05-18', platform: 'linkedin', status: 'published', type: 'post' },
    { id: '4', title: 'Viral Trend Challenge', date: '2024-05-15', platform: 'tiktok', status: 'scheduled', type: 'video' },
    { id: '5', title: 'Industry Insights Thread', date: '2024-05-22', platform: 'twitter', status: 'scheduled', type: 'post' },
  ];

  const days = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  
  // Generating a simple grid for May 2024 (starts on Wednesday)
  const emptyDays = 3; // Offset for May 1st 2024
  const totalDays = 31;

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'published': return 'bg-emerald-500';
      case 'scheduled': return 'bg-indigo-500';
      case 'draft': return 'bg-slate-400';
      default: return 'bg-slate-400';
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center bg-white border border-slate-200 rounded-xl px-2 py-1 shadow-sm">
            <button className="p-2 hover:bg-slate-50 rounded-lg text-slate-400"><ChevronLeft size={18} /></button>
            <span className="px-4 font-bold text-slate-700">May 2024</span>
            <button className="p-2 hover:bg-slate-50 rounded-lg text-slate-400"><ChevronRight size={18} /></button>
          </div>
          <button className="flex items-center gap-2 px-4 py-2 border border-slate-200 rounded-xl bg-white font-medium text-slate-600 hover:bg-slate-50 transition-colors">
            <Filter size={18} />
            <span>Filters</span>
          </button>
        </div>
        <button className="flex items-center justify-center gap-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold shadow-lg shadow-indigo-100 hover:bg-indigo-700 transition-all active:scale-95">
          <Plus size={20} />
          <span>New Content</span>
        </button>
      </div>

      <div className="bg-white rounded-3xl border border-slate-100 shadow-sm p-4 md:p-8 overflow-hidden">
        <div className="grid grid-cols-7 border-b border-slate-100 pb-4 mb-4">
          {days.map(d => (
            <div key={d} className="text-center text-xs font-bold text-slate-400 uppercase tracking-widest">{d}</div>
          ))}
        </div>
        
        <div className="grid grid-cols-7 gap-px bg-slate-100 rounded-xl overflow-hidden border border-slate-100">
          {Array.from({ length: emptyDays }).map((_, i) => (
            <div key={`empty-${i}`} className="min-h-[120px] bg-slate-50/50" />
          ))}
          
          {Array.from({ length: totalDays }).map((_, i) => {
            const day = i + 1;
            const dateStr = `2024-05-${day.toString().padStart(2, '0')}`;
            const dayEvents = events.filter(e => e.date === dateStr);
            
            return (
              <div key={i} className="min-h-[120px] bg-white p-2 md:p-3 hover:bg-slate-50 transition-colors group relative cursor-pointer">
                <p className="text-sm font-bold text-slate-400 group-hover:text-indigo-600 mb-2 transition-colors">{day}</p>
                <div className="space-y-1">
                  {dayEvents.map(event => (
                    <div 
                      key={event.id}
                      className="group/event p-1.5 rounded-lg border text-[10px] font-bold leading-tight flex flex-col gap-1 shadow-sm transition-all hover:translate-y-[-1px] hover:shadow-md"
                      style={{ 
                        backgroundColor: 'white',
                        borderColor: `${PLATFORM_COLORS[event.platform]}30`,
                        borderLeftWidth: '3px',
                        borderLeftColor: PLATFORM_COLORS[event.platform]
                      }}
                    >
                      <div className="flex items-center justify-between">
                        <span style={{ color: PLATFORM_COLORS[event.platform] }}>
                          {PLATFORM_ICONS[event.platform]}
                        </span>
                        <div className={`w-1.5 h-1.5 rounded-full ${getStatusColor(event.status)}`}></div>
                      </div>
                      <span className="truncate text-slate-700">{event.title}</span>
                    </div>
                  ))}
                </div>
                {/* Plus button on hover */}
                <button className="absolute bottom-2 right-2 p-1 bg-indigo-50 text-indigo-600 rounded-md opacity-0 group-hover:opacity-100 transition-opacity">
                  <Plus size={14} />
                </button>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default CalendarView;
