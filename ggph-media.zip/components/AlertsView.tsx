
import React from 'react';
import { Bell, Info, AlertTriangle, TrendingUp, CheckCircle2, Trash2, ShieldAlert } from 'lucide-react';
import { Alert } from '../types';

interface AlertsViewProps {
  alerts: Alert[];
  setAlerts: React.Dispatch<React.SetStateAction<Alert[]>>;
}

const AlertsView: React.FC<AlertsViewProps> = ({ alerts, setAlerts }) => {
  const markAsRead = (id: string) => {
    setAlerts(prev => prev.map(a => a.id === id ? { ...a, read: true } : a));
  };

  const clearAlert = (id: string) => {
    setAlerts(prev => prev.filter(a => a.id !== id));
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'spike': return <TrendingUp className="text-emerald-500" />;
      case 'error': return <ShieldAlert className="text-rose-500" />;
      case 'warning': return <AlertTriangle className="text-amber-500" />;
      case 'info': return <Info className="text-indigo-500" />;
      default: return <Bell className="text-slate-500" />;
    }
  };

  const getAlertBg = (type: string) => {
    switch (type) {
      case 'spike': return 'bg-emerald-50/50';
      case 'error': return 'bg-rose-50/50';
      case 'warning': return 'bg-amber-50/50';
      case 'info': return 'bg-indigo-50/50';
      default: return 'bg-slate-50';
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 animate-in slide-in-from-right-4 duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Notification Center</h2>
          <p className="text-slate-500">Stay updated with real-time performance and system alerts.</p>
        </div>
        <button 
          onClick={() => setAlerts(prev => prev.map(a => ({ ...a, read: true })))}
          className="text-sm font-semibold text-indigo-600 hover:text-indigo-700"
        >
          Mark all as read
        </button>
      </div>

      <div className="space-y-3">
        {alerts.length === 0 ? (
          <div className="bg-white rounded-2xl p-12 border border-dashed border-slate-200 flex flex-col items-center justify-center text-center">
            <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center text-slate-300 mb-4">
              <CheckCircle2 size={32} />
            </div>
            <h3 className="font-bold text-slate-800">No new alerts</h3>
            <p className="text-slate-500">You're all caught up for now!</p>
          </div>
        ) : (
          alerts.map((alert) => (
            <div 
              key={alert.id}
              className={`flex items-start gap-4 p-5 rounded-2xl border transition-all ${
                alert.read ? 'bg-white border-slate-100 opacity-75' : `border-slate-100 shadow-sm ${getAlertBg(alert.type)}`
              }`}
            >
              <div className="p-3 bg-white rounded-xl shadow-sm ring-1 ring-slate-100">
                {getAlertIcon(alert.type)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-1">
                  <span className={`text-[10px] font-bold uppercase tracking-wider ${
                    alert.type === 'error' ? 'text-rose-600' : 'text-slate-400'
                  }`}>
                    {alert.type} Alert
                  </span>
                  <span className="text-xs text-slate-400">{alert.timestamp}</span>
                </div>
                <p className={`font-medium ${alert.read ? 'text-slate-600' : 'text-slate-900'}`}>
                  {alert.message}
                </p>
                {!alert.read && (
                  <button 
                    onClick={() => markAsRead(alert.id)}
                    className="mt-3 text-xs font-bold text-indigo-600 hover:bg-indigo-50 px-2 py-1 rounded"
                  >
                    Mark as resolved
                  </button>
                )}
              </div>
              <button 
                onClick={() => clearAlert(alert.id)}
                className="p-2 text-slate-300 hover:text-rose-500 transition-colors rounded-lg hover:bg-rose-50"
              >
                <Trash2 size={18} />
              </button>
            </div>
          ))
        )}
      </div>

      {/* Subscription/Setting Tip */}
      <div className="bg-indigo-900 rounded-2xl p-6 text-white flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-white/10 rounded-xl">
            <Bell className="text-indigo-200" size={24} />
          </div>
          <div>
            <h4 className="font-bold">Push Notifications</h4>
            <p className="text-indigo-200 text-sm">Get instant alerts on your mobile device for critical ad issues.</p>
          </div>
        </div>
        <button className="px-6 py-2 bg-white text-indigo-900 rounded-xl font-bold text-sm shadow-xl shadow-indigo-950/20">
          Enable
        </button>
      </div>
    </div>
  );
};

export default AlertsView;
