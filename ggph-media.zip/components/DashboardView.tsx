
import React, { useState, useEffect } from 'react';
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  AreaChart,
  Area
} from 'recharts';
import { TrendingUp, TrendingDown, BrainCircuit, Loader2, Info, Plus } from 'lucide-react';
import { MOCK_CHART_DATA, MOCK_STATS, PLATFORM_ICONS, PLATFORM_COLORS } from '../constants';
import { getSocialInsights } from '../services/geminiService';
import { Platform } from '../types';

interface DashboardViewProps {
  onConnectClick: () => void;
  connectedCount: number;
}

const DashboardView: React.FC<DashboardViewProps> = ({ onConnectClick, connectedCount }) => {
  const [aiInsights, setAiInsights] = useState<any[]>([]);
  const [loadingInsights, setLoadingInsights] = useState(false);

  const fetchInsights = async () => {
    setLoadingInsights(true);
    const data = await getSocialInsights(MOCK_STATS);
    setAiInsights(data.insights);
    setLoadingInsights(false);
  };

  useEffect(() => {
    fetchInsights();
  }, []);

  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Onboarding Notice */}
      {connectedCount < 5 && (
        <div className="bg-gradient-to-r from-indigo-600 to-violet-700 p-6 rounded-2xl text-white shadow-lg flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="p-3 bg-white/20 rounded-xl backdrop-blur-md">
              <Plus size={24} />
            </div>
            <div>
              <h3 className="font-bold text-lg">Connect More Platforms</h3>
              <p className="text-indigo-100 text-sm opacity-90">Unlock deeper cross-channel insights by linking your Facebook and Twitter accounts.</p>
            </div>
          </div>
          <button 
            onClick={onConnectClick}
            className="px-6 py-3 bg-white text-indigo-600 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-all shadow-sm whitespace-nowrap"
          >
            Manage Integrations
          </button>
        </div>
      )}

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {(Object.keys(MOCK_STATS) as Platform[]).slice(0, 4).map((p) => (
          <div key={p} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 group hover:border-indigo-200 transition-all">
            <div className="flex items-center justify-between mb-4">
              <div 
                className="p-3 rounded-xl text-white shadow-md group-hover:scale-110 transition-transform" 
                style={{ backgroundColor: PLATFORM_COLORS[p] }}
              >
                {PLATFORM_ICONS[p]}
              </div>
              <div className={`flex items-center text-xs font-bold px-2 py-1 rounded-full ${
                MOCK_STATS[p].growth > 0 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'
              }`}>
                {MOCK_STATS[p].growth > 0 ? <TrendingUp size={14} className="mr-1" /> : <TrendingDown size={14} className="mr-1" />}
                {Math.abs(MOCK_STATS[p].growth)}%
              </div>
            </div>
            <h3 className="text-slate-400 text-sm font-medium uppercase tracking-wider mb-1">{p}</h3>
            <p className="text-3xl font-bold text-slate-900">{MOCK_STATS[p].followers.toLocaleString()}</p>
            <div className="mt-4 pt-4 border-t border-slate-50 flex items-center justify-between text-xs text-slate-500">
              <span>Eng: {MOCK_STATS[p].engagement}%</span>
              <span>Reach: {(MOCK_STATS[p].reach / 1000).toFixed(1)}k</span>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Main Chart */}
        <div className="lg:col-span-2 bg-white p-8 rounded-2xl border border-slate-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h2 className="text-lg font-bold text-slate-800">Aggregated Reach</h2>
              <p className="text-sm text-slate-500">Performance across all connected channels</p>
            </div>
            <select className="bg-slate-50 border-none text-sm font-medium rounded-lg px-3 py-2 outline-none cursor-pointer">
              <option>Last 7 Days</option>
              <option>Last 30 Days</option>
            </select>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={MOCK_CHART_DATA}>
                <defs>
                  <linearGradient id="colorReach" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#6366f1" stopOpacity={0.1}/>
                    <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dy={10} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} dx={-10} />
                <Tooltip 
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)' }}
                  cursor={{ stroke: '#6366f1', strokeWidth: 2 }}
                />
                <Area type="monotone" dataKey="reach" stroke="#6366f1" strokeWidth={3} fillOpacity={1} fill="url(#colorReach)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* AI Insights Panel */}
        <div className="bg-indigo-900 rounded-2xl p-8 text-white shadow-xl relative overflow-hidden group">
          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-6">
              <div className="p-2 bg-indigo-500/30 rounded-lg">
                <BrainCircuit className="text-indigo-200" size={24} />
              </div>
              <h2 className="text-xl font-bold">Smart Insights</h2>
            </div>

            {loadingInsights ? (
              <div className="flex flex-col items-center justify-center h-64 space-y-4">
                <Loader2 className="animate-spin text-indigo-300" size={40} />
                <p className="text-indigo-200 text-sm animate-pulse">Consulting Gemini for latest data trends...</p>
              </div>
            ) : (
              <div className="space-y-6">
                {aiInsights.map((insight, idx) => (
                  <div key={idx} className="bg-white/10 rounded-xl p-4 hover:bg-white/15 transition-colors border border-white/5">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[10px] font-bold uppercase tracking-widest text-indigo-300">{insight.platform}</span>
                      <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold ${
                        insight.impact === 'High' ? 'bg-amber-500 text-white' : 'bg-indigo-500/50 text-indigo-100'
                      }`}>
                        {insight.impact} Impact
                      </span>
                    </div>
                    <h4 className="font-semibold text-sm mb-1">{insight.title}</h4>
                    <p className="text-xs text-indigo-100 leading-relaxed">{insight.description}</p>
                  </div>
                ))}
                <button 
                  onClick={fetchInsights}
                  className="w-full mt-4 py-3 bg-white text-indigo-900 rounded-xl font-bold text-sm hover:bg-indigo-50 transition-colors"
                >
                  Refresh AI Analysis
                </button>
              </div>
            )}
          </div>
          
          {/* Decorative background circles */}
          <div className="absolute top-0 right-0 -mr-20 -mt-20 w-64 h-64 bg-indigo-500/20 rounded-full blur-3xl group-hover:bg-indigo-500/30 transition-all"></div>
          <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-48 h-48 bg-purple-500/20 rounded-full blur-3xl"></div>
        </div>
      </div>
    </div>
  );
};

export default DashboardView;
