
import React, { useState } from 'react';
import { Share2, CheckCircle2, AlertCircle, ShieldCheck, Loader2, ArrowRight } from 'lucide-react';
import { PLATFORM_ICONS, PLATFORM_COLORS } from '../constants';
import { Platform } from '../types';

interface ConnectionsViewProps {
  connected: Platform[];
  setConnected: React.Dispatch<React.SetStateAction<Platform[]>>;
}

const ConnectionsView: React.FC<ConnectionsViewProps> = ({ connected, setConnected }) => {
  const [connecting, setConnecting] = useState<Platform | null>(null);

  const platforms: Platform[] = ['instagram', 'facebook', 'tiktok', 'twitter', 'linkedin'];

  const handleConnect = (p: Platform) => {
    setConnecting(p);
    // Simulate OAuth handshake
    setTimeout(() => {
      setConnected(prev => [...prev, p]);
      setConnecting(null);
    }, 2000);
  };

  const handleDisconnect = (p: Platform) => {
    if (window.confirm(`Are you sure you want to disconnect ${p}? This will pause all automated reporting.`)) {
      setConnected(prev => prev.filter(item => item !== p));
    }
  };

  return (
    <div className="max-w-5xl mx-auto space-y-8 animate-in slide-in-from-bottom-4 duration-500 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-800">Connected Platforms</h2>
          <p className="text-slate-500">Manage your official social media business accounts and ad accounts.</p>
        </div>
        <div className="flex items-center gap-3 px-4 py-2 bg-emerald-50 text-emerald-700 rounded-xl border border-emerald-100 text-sm font-medium">
          <ShieldCheck size={18} />
          <span>AES-256 Encrypted Connection</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {platforms.map(p => {
          const isConnected = connected.includes(p);
          const isProcessing = connecting === p;

          return (
            <div 
              key={p} 
              className={`bg-white rounded-3xl p-8 border transition-all ${
                isConnected ? 'border-indigo-100 shadow-sm' : 'border-slate-100'
              }`}
            >
              <div className="flex items-center justify-between mb-8">
                <div 
                  className="p-4 rounded-2xl text-white shadow-lg" 
                  style={{ backgroundColor: PLATFORM_COLORS[p] }}
                >
                  {PLATFORM_ICONS[p]}
                </div>
                {isConnected ? (
                  <div className="flex items-center gap-1.5 text-emerald-500 font-bold text-xs uppercase tracking-wider">
                    <CheckCircle2 size={16} />
                    <span>Active</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 text-slate-400 font-bold text-xs uppercase tracking-wider">
                    <AlertCircle size={16} />
                    <span>Disconnected</span>
                  </div>
                )}
              </div>

              <h3 className="text-xl font-bold text-slate-800 capitalize mb-2">{p}</h3>
              <p className="text-sm text-slate-500 mb-8 leading-relaxed">
                {isConnected 
                  ? `Connected to GGPH Media for analytics, ad monitoring, and post scheduling.`
                  : `Link your official business account to sync engagement data and campaign ROI.`}
              </p>

              {isConnected ? (
                <div className="space-y-3">
                  <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <img src={`https://picsum.photos/seed/${p}/32/32`} className="w-6 h-6 rounded-full" alt="Account" />
                      <span className="text-xs font-bold text-slate-700">@official_brand</span>
                    </div>
                    <span className="text-[10px] text-slate-400 font-medium">Syncing...</span>
                  </div>
                  <button 
                    onClick={() => handleDisconnect(p)}
                    className="w-full py-3 text-rose-500 font-bold text-sm hover:bg-rose-50 rounded-xl transition-colors"
                  >
                    Disconnect Account
                  </button>
                </div>
              ) : (
                <button 
                  onClick={() => handleConnect(p)}
                  disabled={isProcessing}
                  className="w-full py-4 bg-slate-900 text-white rounded-2xl font-bold text-sm hover:bg-slate-800 transition-all active:scale-[0.98] flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {isProcessing ? (
                    <>
                      <Loader2 size={18} className="animate-spin" />
                      <span>Authorizing...</span>
                    </>
                  ) : (
                    <>
                      <span>Connect {p}</span>
                      <ArrowRight size={18} />
                    </>
                  )}
                </button>
              )}
            </div>
          );
        })}
      </div>

      <div className="bg-white border border-slate-100 rounded-3xl p-8 flex flex-col md:flex-row items-center gap-8">
        <div className="p-6 bg-indigo-50 rounded-3xl text-indigo-600">
          <Share2 size={40} />
        </div>
        <div className="flex-1 text-center md:text-left">
          <h3 className="text-lg font-bold text-slate-800 mb-2">Request Custom Integration</h3>
          <p className="text-slate-500 text-sm max-w-xl">Using a platform not listed here (e.g. Pinterest, YouTube, Snap Ads)? Our Enterprise plan supports custom Webhooks and API integrations.</p>
        </div>
        <button className="px-8 py-3 border-2 border-slate-200 rounded-xl font-bold text-sm hover:bg-slate-50 transition-colors">
          Contact Support
        </button>
      </div>
    </div>
  );
};

export default ConnectionsView;
