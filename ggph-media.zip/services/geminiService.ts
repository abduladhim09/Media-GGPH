
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getSocialInsights = async (stats: any) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Analyze these social media stats and provide 3 actionable professional marketing insights for the team. 
      Stats: ${JSON.stringify(stats)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            insights: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  platform: { type: Type.STRING },
                  title: { type: Type.STRING },
                  description: { type: Type.STRING },
                  impact: { type: Type.STRING, description: 'High, Medium, or Low' }
                },
                required: ["platform", "title", "description", "impact"]
              }
            }
          }
        }
      }
    });

    return JSON.parse(response.text || '{"insights": []}');
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return {
      insights: [
        { platform: "General", title: "Data Refresh Needed", description: "Could not fetch AI insights at this moment.", impact: "Low" }
      ]
    };
  }
};
