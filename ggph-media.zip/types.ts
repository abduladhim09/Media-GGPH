
export type Platform = 'instagram' | 'facebook' | 'tiktok' | 'twitter' | 'linkedin';

export interface PlatformStat {
  platform: Platform;
  followers: number;
  growth: number;
  engagement: number;
  reach: number;
}

export interface AdCampaign {
  id: string;
  name: string;
  platform: Platform;
  status: 'active' | 'paused' | 'ended';
  budget: number;
  spent: number;
  cpc: number;
  ctr: number;
  roi: number;
}

export interface ChartData {
  name: string;
  reach: number;
  impressions: number;
  engagement: number;
}

export interface CalendarEvent {
  id: string;
  title: string;
  date: string;
  platform: Platform;
  status: 'scheduled' | 'published' | 'draft';
  type: 'post' | 'story' | 'video';
}

export interface Alert {
  id: string;
  type: 'spike' | 'error' | 'warning' | 'info';
  message: string;
  timestamp: string;
  read: boolean;
}
