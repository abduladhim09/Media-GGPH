
import React from 'react';
import { Instagram, Facebook, Twitter, Linkedin, Music2 } from 'lucide-react';
import { Platform } from './types';

export const PLATFORM_COLORS: Record<Platform, string> = {
  instagram: '#E4405F',
  facebook: '#1877F2',
  tiktok: '#000000',
  twitter: '#1DA1F2',
  linkedin: '#0A66C2'
};

export const PLATFORM_ICONS: Record<Platform, React.ReactNode> = {
  instagram: <Instagram size={20} />,
  facebook: <Facebook size={20} />,
  tiktok: <Music2 size={20} />,
  twitter: <Twitter size={20} />,
  linkedin: <Linkedin size={20} />
};

export const MOCK_CHART_DATA = [
  { name: 'Mon', reach: 4000, impressions: 2400, engagement: 2400 },
  { name: 'Tue', reach: 3000, impressions: 1398, engagement: 2210 },
  { name: 'Wed', reach: 2000, impressions: 9800, engagement: 2290 },
  { name: 'Thu', reach: 2780, impressions: 3908, engagement: 2000 },
  { name: 'Fri', reach: 1890, impressions: 4800, engagement: 2181 },
  { name: 'Sat', reach: 2390, impressions: 3800, engagement: 2500 },
  { name: 'Sun', reach: 3490, impressions: 4300, engagement: 2100 },
];

export const MOCK_STATS: Record<Platform, any> = {
  instagram: { followers: 12500, growth: 12, engagement: 4.5, reach: 45000 },
  facebook: { followers: 8900, growth: -2, engagement: 2.1, reach: 28000 },
  tiktok: { followers: 45000, growth: 25, engagement: 8.2, reach: 120000 },
  twitter: { followers: 3200, growth: 5, engagement: 1.8, reach: 12000 },
  linkedin: { followers: 1500, growth: 8, engagement: 5.6, reach: 8000 },
};
